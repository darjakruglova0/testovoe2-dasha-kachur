

// $(document).ready(function() {
//   $('#form').submit(function(e) {
//     e.preventDefault();
//     var name = $('#name').val();
//     var email = $('#email').val();
//     var phone = $('#phone').val();
//     var oborot = $('#oborot').val();
//     var industria = $('#industria').val();
//     var check = $('#check').val();
//     $(".error").remove();
 
//     if (name.length< 1) {
//       $('#name').after('<div class="error">Введите свое имя</div>');
//     }
  
//     if (email.length< 1) {
//       $('#email').after('<div class="error">Введите свой email</div>');
//     } else {
//       var regEx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/;
//       var validEmail = regEx.test(email);
//       if (!validEmail) {
//         $('#email').after('<div class="error">Enter a valid email</div>');
//       }
//     }
//     $.ajax({
//       url: '/server.php',         /* Куда отправить запрос */
  
//       dataType: 'html',          /* Тип данных в ответе (xml, json, script, html). */
//        data: formData,     /* Данные передаваемые в массиве */
//       success: function(data){   /* функция которая будет выполнена после успешного запроса.  */
//          alert('спасибо'); /* В переменной data содержится ответ от index.php. */
//       }
//   });
//   });
// });





$('#phone').inputmask("+7(999)999-9999");
$(function() {
$("form").validate({
  rules: {
      name: {
          required: true,
          minlength: 3,
      },

      email: {
          required: true,
          email: true
      },
      
    oborot: {
      required: true,
      number: true
  },
  industria: {
    required: true,
},
check: {
  required: true,
},
  },
  messages:{
email:{
  required:"Поле email обязательное для заполнения",
email:"Укажите почту в формате name@domain.com"
},
name:{
  required:"Имя обязательно должно быть заполнено",
  minlength:"Длина должна быть более 3 символов"
},

oborot: {
  required: "Поле обязательно к заполнению",
  number: "Введите десятичное число"
},
industria: {
  required: "Поле обязательно к заполнению",
},
check: {
  required: "Поле обязательно к заполнению",
}
},

submitHandler: function(form) {
 
 
  $.ajax({




    url: '/server.php',         /* Куда отправить запрос */
    dataType: 'html',          /* Тип данных в ответе (xml, json, script, html). */
    data: $(form).serialize(),    /* Данные передаваемые в массиве */
    success: function(data){  
      
      form.submit(); // uncomment to get the proper submit/* функция которая будет выполнена после успешного запроса.  */
      alert('Спасибо,данные отправлены');
      $(".success").text('Спасибо заказ принят');
    }
});


  }

});

});
